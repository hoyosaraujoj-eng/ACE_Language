#define CRE(Valor) analogWrite(A0, Valor)
#define CFE(Time) delay(500)
#define MACRO_EX(DO64) TOGGLE(Pin)
#define Macrok(Boot, Dx32) SET_PORTB(Mask)